import Image 	
import ImageOps
import ImageFilter
import os

def muda_formato(img, new_name, formato):
	img=Image.open(img)

	#Grava a imagem no formato especificado
	img.save(new_name, formato)
	#img.show(img)

formato = "png"
form = "." + formato

# Vai procurar no diretorio atual
for (nome, sub, arqs) in os.walk("."):
	#Para cada arquivo em arqs
	for arq in arqs:
		#se o arquivo for jpg
		if ".jpg" in arq:
			# junta o jpg com o diretorio
			caminho = os.path.join(nome, arq)
			img = caminho
			# junta o nome do novo arquivo ao seu diretorio
			new_name = os.path.join(nome,  arq.replace(".jpg", form))
			# executa a funcao
			muda_formato(img, new_name, formato)
			print img, "---->",  new_name
