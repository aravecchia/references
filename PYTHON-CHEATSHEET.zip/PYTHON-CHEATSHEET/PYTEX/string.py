s= 'Hello World'
s
print (s)
len(s)
s[:len(s)]
for i in range(0,len(s)):
    print s[i]
#print(len(s)  caracteres.)
s[::-1]