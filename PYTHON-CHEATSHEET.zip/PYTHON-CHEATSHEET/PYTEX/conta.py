for i in range(0,1000001):
    print i