frutas = ["maca","banana","laranja"]
frutas.append("uva")
print(frutas)
