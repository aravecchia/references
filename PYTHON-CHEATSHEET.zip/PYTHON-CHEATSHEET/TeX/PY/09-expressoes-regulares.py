import re
texto="teste@dominio.com"
padrao=r"\w+@\w+\.\w+"
print(re.findall(padrao,texto))
