aluno = {"nome":"Ana","idade":21}
print(aluno["nome"])
