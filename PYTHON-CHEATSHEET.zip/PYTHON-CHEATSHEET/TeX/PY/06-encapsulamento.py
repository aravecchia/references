class Conta:
  def __init__(self,saldo):
    self.__saldo=saldo
  def depositar(self,valor):
    self.__saldo+=valor
  def mostrar_saldo(self):
    print("Saldo:",self.__saldo)
c=Conta(100)
c.depositar(50)
c.mostrar_saldo()
