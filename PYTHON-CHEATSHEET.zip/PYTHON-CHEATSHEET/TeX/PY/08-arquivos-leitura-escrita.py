with open("ex.txt","w") as f:
  f.write("linha1
linha2")
with open("ex.txt","r") as f:
  print(f.read())
