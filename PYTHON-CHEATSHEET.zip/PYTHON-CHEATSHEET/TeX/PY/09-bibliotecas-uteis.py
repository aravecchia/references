import math,random
print(math.pi, random.randint(1,10))
