def deco(func):
  def wrapper():
    print("Antes")
    func()
    print("Depois")
  return wrapper
@deco
def ola():
  print("Ola")
ola()
