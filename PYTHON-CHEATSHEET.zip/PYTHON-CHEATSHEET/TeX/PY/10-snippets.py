x,y=1,2
x,y=y,x
print(x,y)
lista=[1,2,3]
print(lista[::-1])
