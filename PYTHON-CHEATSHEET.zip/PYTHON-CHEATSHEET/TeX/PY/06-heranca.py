class Animal:
  def falar(self):
    print("Som de animal")
class Cachorro(Animal):
  def falar(self):
    print("Au au")
c = Cachorro()
c.falar()
