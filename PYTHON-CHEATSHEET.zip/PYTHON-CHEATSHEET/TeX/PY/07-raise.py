def validar_idade(i):
  if i<0: raise ValueError("Idade negativa")
  print(i)
validar_idade(25)
