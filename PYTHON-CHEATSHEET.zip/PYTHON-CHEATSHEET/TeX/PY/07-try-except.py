try:
  x=int(input("Digite um numero: "))
  print(x)
except ValueError:
  print("Erro")
