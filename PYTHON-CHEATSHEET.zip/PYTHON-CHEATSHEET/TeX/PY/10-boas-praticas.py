def area(b,a):
  """Calcula area"""
  return b*a
print(area(5,3))
