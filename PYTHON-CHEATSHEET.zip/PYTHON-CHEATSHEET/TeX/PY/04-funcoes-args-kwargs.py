def func_args(*args):
  print(args)
func_args(1,2,3)
