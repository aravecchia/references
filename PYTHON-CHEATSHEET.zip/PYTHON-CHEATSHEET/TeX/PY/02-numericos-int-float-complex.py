inteiro = 10
decimal = 3.14
complexo = 1+2j
print(inteiro, decimal, complexo)
