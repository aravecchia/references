class Gato:
  def falar(self):
    print("Miau")
class Cachorro:
  def falar(self):
    print("Au au")
def som(animal):
  animal.falar()
som(Gato())
som(Cachorro())
