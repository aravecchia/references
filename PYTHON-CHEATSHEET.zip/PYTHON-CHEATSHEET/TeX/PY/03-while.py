contador=0
while contador<3:
  print(contador)
  contador+=1
