nome = "Aravekian"
print("Bem-vindo", nome)
