ponto = (10,20)
print(ponto[0])
