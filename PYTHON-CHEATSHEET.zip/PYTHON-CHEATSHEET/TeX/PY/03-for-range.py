for i in range(3):
  print(i)
