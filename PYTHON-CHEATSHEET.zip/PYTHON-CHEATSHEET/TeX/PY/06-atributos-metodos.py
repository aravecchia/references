class Pessoa:
  def __init__(self,nome):
    self.nome = nome
  def saudacao(self):
    print(f"Ola, meu nome eh {self.nome}")
p=Pessoa("Joao")
p.saudacao()
