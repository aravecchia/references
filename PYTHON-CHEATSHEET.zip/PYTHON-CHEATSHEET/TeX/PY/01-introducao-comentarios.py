# Comentarios em Python
# Comentario de uma linha
"""
Comentario de multiplas linhas
"""
print("Comentarios explicativos")
