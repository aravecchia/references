def cont(max):
  n=0
  while n<max:
    yield n
    n+=1
for i in cont(5):
  print(i)
