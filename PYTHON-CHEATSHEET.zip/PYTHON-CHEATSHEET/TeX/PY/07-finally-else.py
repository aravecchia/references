try:
  x=10/2
except ZeroDivisionError:
  print("Divisao por zero")
else:
  print("Sucesso")
finally:
  print("Fim")
