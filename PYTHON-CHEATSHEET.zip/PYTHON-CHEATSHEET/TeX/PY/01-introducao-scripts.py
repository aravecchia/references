# Script de exemplo
mensagem = "Executando script Python"
print(mensagem)
