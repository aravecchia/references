matriz=[[i*j for j in range(3)] for i in range(3)]
print(matriz)
