with open("ex.txt","r") as f:
  for l in f:
    print(l.strip())
