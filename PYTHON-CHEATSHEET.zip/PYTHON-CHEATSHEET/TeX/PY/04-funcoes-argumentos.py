def saudacao(nome,idade):
  print(f"Ola {nome}, voce tem {idade} anos")
saudacao("Ana",25)
