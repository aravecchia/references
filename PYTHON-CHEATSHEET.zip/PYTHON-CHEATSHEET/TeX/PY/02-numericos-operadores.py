x = 10
y = 3
print(x+y, x-y, x*y, x/y, x//y, x%y, x**y)
