def func_generica(x):
  return x
print(func_generica("texto"))
print(func_generica(42))
