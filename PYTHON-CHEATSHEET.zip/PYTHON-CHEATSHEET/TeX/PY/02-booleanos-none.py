ativo = True
nada = None
print(ativo, nada)
