valores = {1,2,2,3}
print(valores)
