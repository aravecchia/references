texto = "python"
print(texto.upper(), texto.capitalize(), texto.replace("p","P"))
