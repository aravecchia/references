x = 7
if x>10:
  print("Maior que 10")
elif x==7:
  print("Igual a 7")
else:
  print("Menor que 7")
