class Pessoa:
  def __init__(self,nome):
    self.nome = nome
p = Pessoa("Ana")
print(p.nome)
