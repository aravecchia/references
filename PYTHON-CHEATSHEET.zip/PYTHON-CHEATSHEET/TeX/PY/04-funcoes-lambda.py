dobro = lambda x: x*2
print(dobro(5))
